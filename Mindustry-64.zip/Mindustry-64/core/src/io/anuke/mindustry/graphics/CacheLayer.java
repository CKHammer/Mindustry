package io.anuke.mindustry.graphics;

public enum CacheLayer{
    water,
    lava,
    oil,
    space,
    normal,
    walls;

    public void begin(){

    }

    public void end(){

    }
}
