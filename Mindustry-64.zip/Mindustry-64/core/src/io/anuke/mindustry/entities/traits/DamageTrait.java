package io.anuke.mindustry.entities.traits;

public interface DamageTrait{
    float damage();
}
