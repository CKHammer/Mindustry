package io.anuke.mindustry.entities.type.base;

import io.anuke.mindustry.entities.type.FlyingUnit;

public class Wraith extends FlyingUnit{

}
