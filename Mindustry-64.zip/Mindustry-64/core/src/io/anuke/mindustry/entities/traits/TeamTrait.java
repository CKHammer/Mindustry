package io.anuke.mindustry.entities.traits;

import io.anuke.mindustry.game.Team;

public interface TeamTrait extends Entity{
    Team getTeam();
}
