package io.anuke.mindustry.entities.type.base;

public class Spirit extends Drone{
}
