package io.anuke.mindustry.entities.type.base;

import io.anuke.mindustry.entities.type.GroundUnit;

public class Titan extends GroundUnit{

}
