package io.anuke.mindustry.entities.type.base;

public class Phantom extends Drone{

}
