package io.anuke.mindustry.entities.type.base;

import io.anuke.mindustry.entities.type.GroundUnit;

public class Crawler extends GroundUnit{
}
