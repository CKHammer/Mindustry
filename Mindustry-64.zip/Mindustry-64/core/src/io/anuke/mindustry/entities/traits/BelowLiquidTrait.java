package io.anuke.mindustry.entities.traits;

/**
 * A flag interface for marking an effect as appearing below liquids.
 */
public interface BelowLiquidTrait{
}
