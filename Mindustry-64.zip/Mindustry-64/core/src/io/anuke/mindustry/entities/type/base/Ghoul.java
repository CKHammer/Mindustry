package io.anuke.mindustry.entities.type.base;

import io.anuke.mindustry.entities.type.FlyingUnit;

public class Ghoul extends FlyingUnit{

}
