package io.anuke.mindustry.ui.fragments;

import io.anuke.arc.scene.Group;

public abstract class Fragment{
    public abstract void build(Group parent);
}
