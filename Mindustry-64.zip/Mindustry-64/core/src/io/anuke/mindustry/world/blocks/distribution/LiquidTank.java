package io.anuke.mindustry.world.blocks.distribution;

public class LiquidTank extends LiquidRouter{

    public LiquidTank(String name){
        super(name);
    }
}
