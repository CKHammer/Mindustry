package io.anuke.mindustry.world.producers;

public class Produce{
}
