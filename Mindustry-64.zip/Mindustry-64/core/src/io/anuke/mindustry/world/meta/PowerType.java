package io.anuke.mindustry.world.meta;

public enum PowerType{
    consumer,
    producer,
    bridge
}
