package io.anuke.mindustry.world.blocks.logic;

import io.anuke.mindustry.world.Block;

public class LogicBlock extends Block{

    public LogicBlock(String name){
        super(name);
    }
}
