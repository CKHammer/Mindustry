package io.anuke.mindustry.world.meta;

public enum BlockGroup{
    none, walls, turrets, transportation, power, liquids, drills
}
