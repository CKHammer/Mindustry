package io.anuke.mindustry.input;

enum PlaceMode{
    none, breaking, placing
}
